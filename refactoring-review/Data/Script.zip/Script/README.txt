#Replication package for code review and refactoring study. 

-To obtain code review mining results open and execute 
all notebook cells in the file Code_reviews_analysis.ipynb.
You can change the global variables to obtain 
the results for different projects.
results will be saved in the same directory of the code.

-To obtain code repositories statistics open and execute all 
notebooks cells in the file projects stats.ipynb. 
You can change the global variables
 as mentionned in the code comments
 to obtain  the results for different projects.