import csv
from os import listdir
from os.path import isfile, join


def combineCsv(files):
    allData = []
    for filepath in files:
        with open(filepath) as file:
            reader = csv.reader(file)
            data = list(reader)
            if len(data) != 0:
                data.pop(0)
            allData = allData + data
    return allData


def saveCsv(data, filepath):
    with open(filepath + "/AllData.csv", "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(data)


if __name__ == '__main__':
    filepath = input(
        "Where is the location of the containing folder for the before and after folders? ")
    beforeFiles = [join(filepath + "/BeforeWilcoxonSorted", file) for file in listdir(filepath + "/BeforeWilcoxonSorted")
                   if isfile(join(filepath + "/BeforeWilcoxonSorted", file))]
    afterFiles = [join(filepath + "/AfterWilcoxonSorted", file) for file in listdir(filepath + "/AfterWilcoxonSorted")
                  if isfile(join(filepath + "/AfterWilcoxonSorted", file))]
    beforeData = combineCsv(beforeFiles)
    afterData = combineCsv(afterFiles)
    with open(filepath + "/AllDataBefore.csv", "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(beforeData)
    with open(filepath + "/AllDataAfter.csv", "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(afterData)
