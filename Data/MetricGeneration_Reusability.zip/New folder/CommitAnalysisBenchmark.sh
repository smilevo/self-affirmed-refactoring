#!/bin/sh

input=tosem_and_mobilesoft_all_projects_and_unique_commits_with_reus_in_message_Part1.csv
repo_home=F:/ReusabilityRefactorings


repo_clone_output=$repo_home/Projects
repo_changed_files=$repo_home/ProjectsWithOnlyChangedFiles
tmpIFS=$IFS
IFS=','

declare -a arr_cloned_commit
count=0

mkdir Metrics
mkdir Metrics/Before
mkdir Metrics/After

#Clone Projects before and after commits

[ ! -f $input ] && {
  echo "$input file not found"
  exit 99
}
while read project_url commit_id_with_CRLF; do
  #echo "URL : $project_url"
  #echo "CommitID : $commit_id"
  #echo "Filename: $filename"
  commit_id=${commit_id_with_CRLF::-1} #Becareful about the CRLF from each row
  #echo $commit_id

  cloned="f"

  #echo " ${arr_cloned_commit[*]} "

  #check if the commit has already been cloned
  for c in "${arr_cloned_commit[@]}"; do
    if [ $c = $commit_id ]; then
      cloned="y"
    fi
  done

  repo_commit=$repo_clone_output/$commit_id
  repo_after_commit=$repo_commit/After
  repo_before_commit=$repo_commit/Before

  if [ $cloned != "y" ]; then #if not cloned, clone the project
    git clone $project_url $repo_after_commit
    cd $repo_after_commit
    git checkout $commit_id
    git diff --name-status HEAD^ HEAD >diff.txt
    mv diff.txt $repo_commit

    cd $repo_commit
    cp -r $repo_after_commit/. $repo_before_commit
    #git clone $project_url $repo_before_commit
    cd $repo_before_commit
    git checkout $commit_id
    git checkout Head^
    arr_cloned_commit[count]=$commit_id
    count=$((count + 1))
  fi

  cd $repo_commit

  mkdir -p $repo_changed_files/$commit_id/Before
  mkdir -p $repo_changed_files/$commit_id/After
  git_diff_input=$repo_commit/diff.txt

  #Select changed file
  IFS=$tmpIFS
  [ ! -f $git_diff_input ] && {
    echo "$git_diff_input file not found"
    exit 99
  }
  while read status filepath filepath_new; do
    #echo $status
    #echo $filepath
    #echo $filepath_new

    if [ $status == "M" ]; then
      cp $repo_before_commit/$filepath $repo_changed_files/$commit_id/Before
      cp $repo_after_commit/$filepath $repo_changed_files/$commit_id/After
    elif [ $status == "D" ]; then
      cp $repo_before_commit/$filepath $repo_changed_files/$commit_id/Before
    elif [ $status == "A" ]; then
      cp $repo_after_commit/$filepath $repo_changed_files/$commit_id/After
    elif [ ${status:0:1} == "R" ]; then
      cp $repo_before_commit/$filepath $repo_changed_files/$commit_id/Before
      cp $repo_after_commit/$filepath_new $repo_changed_files/$commit_id/After
    fi

  done <$git_diff_input
  #cd $repo_home

  #run understand on files before commits
  repo_files_before_commit=$repo_home/ProjectsWithOnlyChangedFiles/$commit_id/Before
  cd $repo_files_before_commit
  for file in $repo_files_before_commit; do
        echo "Start process $file"
        udb_file_before=$commit_id\_before.udb
        und create -db $udb_file_before -languages java
        und add "$file" -db $udb_file_before
        und settings -Metrics all -db $udb_file_before
        und analyze $udb_file_before
        und metrics $udb_file_before
        mv $repo_files_before_commit/$commit_id\_before.csv $repo_home/Metrics/Before
        rm -rf $udb_file_before
    #quit
  done

  #run understand on files after commits
    repo_files_after_commit=$repo_home/ProjectsWithOnlyChangedFiles/$commit_id/After
    cd $repo_files_after_commit
    for file in $repo_files_after_commit; do
      echo "Start process $file"
      udb_file_after=$commit_id\_after.udb
      und create -db $udb_file_after -languages java
      und add "$file" -db $udb_file_after
      und settings -Metrics all -db $udb_file_after
      und analyze $udb_file_after
      und metrics $udb_file_after
      mv $repo_files_after_commit/$commit_id\_after.csv $repo_home/Metrics/After
      rm -rf $udb_file_after
      #quit
    done

  IFS=","

done <$input
IFS=$tmpIFS
unset arr_cloned_commit

cd $repo_home
