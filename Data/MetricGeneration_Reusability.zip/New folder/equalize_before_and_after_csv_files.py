from __future__ import print_function
import os
import operator
import shutil
import csv

basePath = "Metrics/"

beforeDirectoryPath = basePath + "Before/"
beforeEntries = os.listdir(beforeDirectoryPath)
beforeRemovedDulpPath = basePath + "BeforeRemovedDulp/"
if os.path.exists(beforeRemovedDulpPath):
    shutil.rmtree(beforeRemovedDulpPath)
os.makedirs(beforeRemovedDulpPath)
beforeWilcoxonDirectoryPath = basePath + "BeforeWilcoxon/"
if os.path.exists(beforeWilcoxonDirectoryPath):
    shutil.rmtree(beforeWilcoxonDirectoryPath)
os.makedirs(beforeWilcoxonDirectoryPath)
beforeWilcoxonSortedDirectoryPath = basePath + "BeforeWilcoxonSorted/"
if os.path.exists(beforeWilcoxonSortedDirectoryPath):
    shutil.rmtree(beforeWilcoxonSortedDirectoryPath)
os.makedirs(beforeWilcoxonSortedDirectoryPath)

afterDirectoryPath = basePath + "After/"
afterEntries = os.listdir(afterDirectoryPath)
afterRemovedDulpPath = basePath + "AfterRemovedDulp/"
if os.path.exists(afterRemovedDulpPath):
    shutil.rmtree(afterRemovedDulpPath)
os.makedirs(afterRemovedDulpPath)
afterWilcoxonDirectoryPath = basePath + "AfterWilcoxon/"
if os.path.exists(afterWilcoxonDirectoryPath):
    shutil.rmtree(afterWilcoxonDirectoryPath)
os.makedirs(afterWilcoxonDirectoryPath)
afterWilcoxonSortedDirectoryPath = basePath + "AfterWilcoxonSorted/"
if os.path.exists(afterWilcoxonSortedDirectoryPath):
    shutil.rmtree(afterWilcoxonSortedDirectoryPath)
os.makedirs(afterWilcoxonSortedDirectoryPath)

originalFieldnames = ["Kind","Name","AvgCyclomatic","AvgCyclomaticModified","AvgCyclomaticStrict","AvgEssential","AvgLine","AvgLineBlank","AvgLineCode","AvgLineComment","CountClassBase","CountClassCoupled","CountClassCoupledModified","CountClassDerived","CountDeclClass","CountDeclClassMethod","CountDeclClassVariable","CountDeclExecutableUnit","CountDeclFile","CountDeclFunction","CountDeclInstanceMethod","CountDeclInstanceVariable","CountDeclMethod","CountDeclMethodAll","CountDeclMethodDefault","CountDeclMethodPrivate","CountDeclMethodProtected","CountDeclMethodPublic","CountInput","CountLine","CountLineBlank","CountLineCode","CountLineCodeDecl","CountLineCodeExe","CountLineComment","CountOutput","CountPath","CountPathLog","CountSemicolon","CountStmt","CountStmtDecl","CountStmtExe","Cyclomatic","CyclomaticModified","CyclomaticStrict","Essential","Knots","MaxCyclomatic","MaxCyclomaticModified","MaxCyclomaticStrict","MaxEssential","MaxEssentialKnots","MaxInheritanceTree","MaxNesting","MinEssentialKnots","PercentLackOfCohesion","PercentLackOfCohesionModified","RatioCommentToCode","SumCyclomatic","SumCyclomaticModified","SumCyclomaticStrict","SumEssential"]

truncFieldnames = ["Kind","Name","CountClassBase","CountClassCoupled","CountClassDerived","CountDeclFunction","CountDeclInstanceMethod","CountDeclInstanceVariable","CountDeclMethodAll","CountLineCode","MaxInheritanceTree","PercentLackOfCohesion","RatioCommentToCode","SumCyclomatic"]

commitIdList = []
beforeEntriesStr = str(beforeEntries)
for entry in beforeEntries:
    entryStr = str(entry)
    beforeSubstringIndex = entryStr.index("_before.csv")
    commitIdStr = entryStr[:beforeSubstringIndex]
    commitIdList.append(commitIdStr)

    beforeOriginFilePath = beforeDirectoryPath + commitIdStr + "_before.csv"
    beforeOriginFile = open(beforeOriginFilePath, mode="r", newline="")
    beforeOriginCsvReader = csv.DictReader(beforeOriginFile)
    nameExistBefore = []
    beforeRemoveDulpFilePath = beforeRemovedDulpPath + commitIdStr + "_before.csv"
    beforeRemoveDulpFile = open(beforeRemoveDulpFilePath, mode="w", newline="")
    beforeRemoveDulpCsvWriter = csv.DictWriter(beforeRemoveDulpFile, fieldnames=originalFieldnames)
    beforeRemoveDulpCsvWriter.writeheader()
    for beforeRow in beforeOriginCsvReader:
        if beforeRow["Name"] not in nameExistBefore:
            beforeRemoveDulpCsvWriter.writerow(beforeRow)
            nameExistBefore.append(beforeRow["Name"])
    beforeRemoveDulpFile.close()
    beforeOriginFile.close()

    afterOriginFilePath = afterDirectoryPath + commitIdStr + "_after.csv"
    afterOriginFile = open(afterOriginFilePath, mode="r", newline="")
    afterOriginCsvReader = csv.DictReader(afterOriginFile)
    nameExistAfter = []
    afterRemoveDulpFilePath = afterRemovedDulpPath + commitIdStr + "_after.csv"
    afterRemoveDulpFile = open(afterRemoveDulpFilePath, mode="w", newline="")
    afterRemoveDulpCsvWriter = csv.DictWriter(afterRemoveDulpFile, fieldnames=originalFieldnames)
    afterRemoveDulpCsvWriter.writeheader()
    for afterRow in afterOriginCsvReader:
        if afterRow["Name"] not in nameExistAfter:
            afterRemoveDulpCsvWriter.writerow(afterRow)
            nameExistAfter.append(afterRow["Name"])
    afterRemoveDulpFile.close()
    afterOriginFile.close()


    # entryStr = str(entry)
    # beforeSubstringIndex = entryStr.index("_before.csv")
    # commitIdStr = entryStr[:beforeSubstringIndex]
    # commitIdList.append(commitIdStr)
    beforeFilePath = beforeRemoveDulpFilePath
    beforeWilcoxonFilePath = beforeWilcoxonDirectoryPath + commitIdStr + "_before.csv"
    beforeSortedFilePath = beforeWilcoxonSortedDirectoryPath + commitIdStr + "_before.csv"
    afterFilePath = afterRemoveDulpFilePath
    afterWilcoxonFilePath = afterWilcoxonDirectoryPath + commitIdStr + "_after.csv"
    afterSortedFilePath = afterWilcoxonSortedDirectoryPath + commitIdStr + "_after.csv"
    shutil.copy(beforeFilePath, beforeWilcoxonDirectoryPath)
    shutil.copy(afterFilePath, afterWilcoxonDirectoryPath)


    beforeFile = open(beforeFilePath, mode="r", newline="")
    beforeCsvReader = csv.DictReader(beforeFile)
    for beforeRow in beforeCsvReader:
        beforeCodeElementExistsInAfterFile = False
        afterFile = open(afterFilePath, mode="r", newline="")
        afterCsvReader = csv.DictReader(afterFile)
        for afterRow in afterCsvReader:
            if beforeRow["Name"] == afterRow["Name"]:
                beforeCodeElementExistsInAfterFile = True
        afterFile.close()
        if beforeCodeElementExistsInAfterFile == False:
            afterFile = open(afterWilcoxonFilePath, mode="a", newline="")
            afterCsvWriter = csv.DictWriter(afterFile, fieldnames=originalFieldnames)
            beforeRowToCopy = beforeRow
            beforeRowToCopy["AvgCyclomatic"] = ""
            beforeRowToCopy["AvgCyclomaticModified"] = ""
            beforeRowToCopy["AvgCyclomaticStrict"] = ""
            beforeRowToCopy["AvgEssential"] = ""
            beforeRowToCopy["AvgLine"] = ""
            beforeRowToCopy["AvgLineBlank"] = ""
            beforeRowToCopy["AvgLineCode"] = ""
            beforeRowToCopy["AvgLineComment"] = ""
            beforeRowToCopy["CountClassBase"] = ""
            beforeRowToCopy["CountClassCoupled"] = ""
            beforeRowToCopy["CountClassCoupledModified"] = ""
            beforeRowToCopy["CountClassDerived"] = ""
            beforeRowToCopy["CountDeclClass"] = ""
            beforeRowToCopy["CountDeclClassMethod"] = ""
            beforeRowToCopy["CountDeclClassVariable"] = ""
            beforeRowToCopy["CountDeclExecutableUnit"] = ""
            beforeRowToCopy["CountDeclFile"] = ""
            beforeRowToCopy["CountDeclFunction"] = ""
            beforeRowToCopy["CountDeclInstanceMethod"] = ""
            beforeRowToCopy["CountDeclInstanceVariable"] = ""
            beforeRowToCopy["CountDeclMethod"] = ""
            beforeRowToCopy["CountDeclMethodAll"] = ""
            beforeRowToCopy["CountDeclMethodDefault"] = ""
            beforeRowToCopy["CountDeclMethodPrivate"] = ""
            beforeRowToCopy["CountDeclMethodProtected"] = ""
            beforeRowToCopy["CountDeclMethodPublic"] = ""
            beforeRowToCopy["CountInput"] = ""
            beforeRowToCopy["CountLine"] = ""
            beforeRowToCopy["CountLineBlank"] = ""
            beforeRowToCopy["CountLineCode"] = ""
            beforeRowToCopy["CountLineCodeDecl"] = ""
            beforeRowToCopy["CountLineCodeExe"] = ""
            beforeRowToCopy["CountLineComment"] = ""
            beforeRowToCopy["CountOutput"] = ""
            beforeRowToCopy["CountPath"] = ""
            beforeRowToCopy["CountPathLog"] = ""
            beforeRowToCopy["CountSemicolon"] = ""
            beforeRowToCopy["CountStmt"] = ""
            beforeRowToCopy["CountStmtDecl"] = ""
            beforeRowToCopy["CountStmtExe"] = ""
            beforeRowToCopy["Cyclomatic"] = ""
            beforeRowToCopy["CyclomaticModified"] = ""
            beforeRowToCopy["CyclomaticStrict"] = ""
            beforeRowToCopy["Essential"] = ""
            beforeRowToCopy["Knots"] = ""
            beforeRowToCopy["MaxCyclomatic"] = ""
            beforeRowToCopy["MaxCyclomaticModified"] = ""
            beforeRowToCopy["MaxCyclomaticStrict"] = ""
            beforeRowToCopy["MaxEssential"] = ""
            beforeRowToCopy["MaxEssentialKnots"] = ""
            beforeRowToCopy["MaxInheritanceTree"] = ""
            beforeRowToCopy["MaxNesting"] = ""
            beforeRowToCopy["MinEssentialKnots"] = ""
            beforeRowToCopy["PercentLackOfCohesion"] = ""
            beforeRowToCopy["PercentLackOfCohesionModified"] = ""
            beforeRowToCopy["RatioCommentToCode"] = ""
            beforeRowToCopy["SumCyclomatic"] = ""
            beforeRowToCopy["SumCyclomaticModified"] = ""
            beforeRowToCopy["SumCyclomaticStrict"] = ""
            beforeRowToCopy["SumEssential"] = ""
            afterCsvWriter.writerow(beforeRowToCopy)
            afterFile.close()
    beforeFile.close()

    afterFile = open(afterFilePath, mode="r", newline="")
    afterCsvReader = csv.DictReader(afterFile)
    for afterRow in afterCsvReader:
        afterCodeElementExistsInBeforeFile = False
        beforeFile = open(beforeFilePath, mode="r", newline="")
        beforeCsvReader = csv.DictReader(beforeFile)
        for beforeRow in beforeCsvReader:
            if afterRow["Name"] == beforeRow["Name"]:
                afterCodeElementExistsInBeforeFile = True
        beforeFile.close()
        if afterCodeElementExistsInBeforeFile == False:
            beforeFile = open(beforeWilcoxonFilePath, mode="a", newline="")
            beforeCsvWriter = csv.DictWriter(beforeFile, fieldnames=originalFieldnames)
            afterRowToCopy = afterRow
            afterRowToCopy["AvgCyclomatic"] = ""
            afterRowToCopy["AvgCyclomaticModified"] = ""
            afterRowToCopy["AvgCyclomaticStrict"] = ""
            afterRowToCopy["AvgEssential"] = ""
            afterRowToCopy["AvgLine"] = ""
            afterRowToCopy["AvgLineBlank"] = ""
            afterRowToCopy["AvgLineCode"] = ""
            afterRowToCopy["AvgLineComment"] = ""
            afterRowToCopy["CountClassBase"] = ""
            afterRowToCopy["CountClassCoupled"] = ""
            afterRowToCopy["CountClassCoupledModified"] = ""
            afterRowToCopy["CountClassDerived"] = ""
            afterRowToCopy["CountDeclClass"] = ""
            afterRowToCopy["CountDeclClassMethod"] = ""
            afterRowToCopy["CountDeclClassVariable"] = ""
            afterRowToCopy["CountDeclExecutableUnit"] = ""
            afterRowToCopy["CountDeclFile"] = ""
            afterRowToCopy["CountDeclFunction"] = ""
            afterRowToCopy["CountDeclInstanceMethod"] = ""
            afterRowToCopy["CountDeclInstanceVariable"] = ""
            afterRowToCopy["CountDeclMethod"] = ""
            afterRowToCopy["CountDeclMethodAll"] = ""
            afterRowToCopy["CountDeclMethodDefault"] = ""
            afterRowToCopy["CountDeclMethodPrivate"] = ""
            afterRowToCopy["CountDeclMethodProtected"] = ""
            afterRowToCopy["CountDeclMethodPublic"] = ""
            afterRowToCopy["CountInput"] = ""
            afterRowToCopy["CountLine"] = ""
            afterRowToCopy["CountLineBlank"] = ""
            afterRowToCopy["CountLineCode"] = ""
            afterRowToCopy["CountLineCodeDecl"] = ""
            afterRowToCopy["CountLineCodeExe"] = ""
            afterRowToCopy["CountLineComment"] = ""
            afterRowToCopy["CountOutput"] = ""
            afterRowToCopy["CountPath"] = ""
            afterRowToCopy["CountPathLog"] = ""
            afterRowToCopy["CountSemicolon"] = ""
            afterRowToCopy["CountStmt"] = ""
            afterRowToCopy["CountStmtDecl"] = ""
            afterRowToCopy["CountStmtExe"] = ""
            afterRowToCopy["Cyclomatic"] = ""
            afterRowToCopy["CyclomaticModified"] = ""
            afterRowToCopy["CyclomaticStrict"] = ""
            afterRowToCopy["Essential"] = ""
            afterRowToCopy["Knots"] = ""
            afterRowToCopy["MaxCyclomatic"] = ""
            afterRowToCopy["MaxCyclomaticModified"] = ""
            afterRowToCopy["MaxCyclomaticStrict"] = ""
            afterRowToCopy["MaxEssential"] = ""
            afterRowToCopy["MaxEssentialKnots"] = ""
            afterRowToCopy["MaxInheritanceTree"] = ""
            afterRowToCopy["MaxNesting"] = ""
            afterRowToCopy["MinEssentialKnots"] = ""
            afterRowToCopy["PercentLackOfCohesion"] = ""
            afterRowToCopy["PercentLackOfCohesionModified"] = ""
            afterRowToCopy["RatioCommentToCode"] = ""
            afterRowToCopy["SumCyclomatic"] = ""
            afterRowToCopy["SumCyclomaticModified"] = ""
            afterRowToCopy["SumCyclomaticStrict"] = ""
            afterRowToCopy["SumEssential"] = ""
            beforeCsvWriter.writerow(afterRowToCopy)
            beforeFile.close()
    afterFile.close()

    beforeFile = open(beforeWilcoxonFilePath, mode="r", newline="")
    beforeFileSorted = open(beforeSortedFilePath, mode="w", newline="")
    beforeCsvReader = csv.reader(beforeFile)
    beforeSortedCsvWriter = csv.writer(beforeFileSorted)
    header = next(beforeCsvReader, None)
    beforeSortedRows = sorted(beforeCsvReader, key=operator.itemgetter(1))
    if header:
        beforeSortedCsvWriter.writerow(header)
    for beforeRow in beforeSortedRows:
        beforeSortedCsvWriter.writerow(beforeRow)
    beforeFile.close()
    beforeFileSorted.close()

    afterFile = open(afterWilcoxonFilePath, mode="r", newline="")
    afterFileSorted = open(afterSortedFilePath, mode="w", newline="")
    afterCsvReader = csv.reader(afterFile)
    afterSortedCsvWriter = csv.writer(afterFileSorted)
    header = next(afterCsvReader, None)
    afterSortedRows = sorted(afterCsvReader, key=operator.itemgetter(1))
    if header:
        afterSortedCsvWriter.writerow(header)
    for afterRow in afterSortedRows:
        afterSortedCsvWriter.writerow(afterRow)
    afterFile.close()
    afterFileSorted.close()

# keep the sorted Wilcoxon directories, but remove the regular Wilcoxon directories
shutil.rmtree(beforeWilcoxonDirectoryPath)
shutil.rmtree(afterWilcoxonDirectoryPath)