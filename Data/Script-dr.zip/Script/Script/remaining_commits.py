import pandas as pd
import numpy as np
import sqlite3 as sql
import warnings
import time
from bson import ObjectId
from mongoengine import connect, disconnect
from pycoshark.mongomodels import Refactoring, Commit
from pymongo import MongoClient


warnings.filterwarnings('ignore', category=FutureWarning)

'''
This script loads the remaining commits that are linked to Refactoring collection in MongoDB but
are not present in the SQLite DB
'''

print("Process started!")
time_analysis_start = time.time()

# create connection to mongo db server using raw client
client = MongoClient("mongodb://localhost:27018/")
database = client["smartshark_2_2"]

# create connection to local sqlite db
database_name = "/Users/hdagar3/Downloads/msr2022_challenge_refactoring_summer2023.sqlite"
connection = sql.connect(database_name)

# create connection to mongo db server using mongoengine i.e. with ORM
disconnect('default')
connect('smartshark_2_2', host='localhost', port=27018, alias='default')

query = 'SELECT id FROM "commit"'
df = pd.read_sql_query(query, connection)

existing_commit_ids = df['id'].tolist()

# if you want to count the number of commit ids
print(len(existing_commit_ids))
existing_commit_ids = set(existing_commit_ids)

commit_ids_to_be_processed = set()
commits = Refactoring.objects.distinct('commit_id')
print(type(commits), type(existing_commit_ids))
print(len(commits))

for commit_id in commits:
    if str(commit_id) not in existing_commit_ids:
        commit_ids_to_be_processed.add(str(commit_id))

count_distinct_refactoring_commits = len(commit_ids_to_be_processed)
print('Total distinct remaining refactoring commits: %s' % count_distinct_refactoring_commits)

df_output_commit = pd.DataFrame(columns=[
    'id',
    'author_date',
    'author_date_offset',
    'author_id',
    'committer_date',
    'committer_date_offset',
    'committer_id',
    'revision_hash',
    'vcs_system_id',
    'project_id',
    'project_name',
    'message'
])

df_output_commit_label = pd.DataFrame(columns=[
    'commit_id',
    'label_name',
    'label_value'
])

df_output_commit_linkedissue = pd.DataFrame(columns=[
    'commit_id',
    'issue_id'
])

df_output_commit_fixedissue = pd.DataFrame(columns=[
    'commit_id',
    'issue_id'
])

df_output_commit_szzissue = pd.DataFrame(columns=[
    'commit_id',
    'issue_id'
])

df_output_error = pd.DataFrame(columns=[
    'commit_id'
])

count_distinct_refactoring_commits = len(commit_ids_to_be_processed)
print('Total distinct refactoring commits: %s' %count_distinct_refactoring_commits)

count = 1
for commit_id in commit_ids_to_be_processed:
    if commit_id is not None:
        print('Analyzing commit %s of %s [%s]...' % (count, count_distinct_refactoring_commits, (count/count_distinct_refactoring_commits)*100.0), end='', flush=True)
        count += 1
        # commit = Commit.objects.with_id(object_id=commit_id)

        cursor = database["commit"].find({"_id": ObjectId(commit_id)})
        for doc in cursor:
            id = doc["_id"]
            author_date = doc["author_date"]
            author_date_offset = doc["author_date_offset"]
            author_id = doc["author_id"]
            committer_date = doc["committer_date"]
            committer_date_offset = doc["committer_date_offset"]
            committer_id = doc["committer_id"]
            revision_hash = doc["revision_hash"]
            vcs_system_id = doc["vcs_system_id"]
            project_id = VCSSystem.objects.with_id(object_id=vcs_system_id).project_id
            project_name = Project.objects.with_id(object_id=project_id).name
            message = doc["message"]

            df_output_commit = df_output_commit.append({
                'id': str(id),
                'author_date': author_date,
                'author_date_offset': author_date_offset,
                'author_id': str(author_id),
                'committer_date': committer_date,
                'committer_date_offset': committer_date_offset,
                'committer_id': str(committer_id),
                'revision_hash': revision_hash,
                'vcs_system_id': str(vcs_system_id),
                'project_id': str(project_id),
                'project_name': project_name,
                'message': message
            }, ignore_index=True)

            if len(doc.get("labels", [])) > 0:
                for label in doc["labels"]:
                    df_output_commit_label = df_output_commit_label.append({
                        'commit_id': str(id),
                        'label_name': label,
                        'label_value': doc["labels"][label]
                    }, ignore_index=True)

            if len(doc.get("linked_issue_ids", [])) > 0:
                for issue in doc["linked_issue_ids"]:
                    df_output_commit_linkedissue = df_output_commit_linkedissue.append({
                        'commit_id': str(id),
                        'issue_id': str(issue)
                    }, ignore_index=True)

            if len(doc.get("fixed_issue_ids", [])) > 0:
                for issue in doc["fixed_issue_ids"]:
                    df_output_commit_fixedissue = df_output_commit_fixedissue.append({
                        'commit_id': str(id),
                        'issue_id': str(issue)
                    }, ignore_index=True)

            if len(doc.get("szz_issue_ids", [])) > 0:
                for issue in doc["szz_issue_ids"]:
                    df_output_commit_szzissue = df_output_commit_szzissue.append({
                        'commit_id': str(id),
                        'issue_id': str(issue)
                    }, ignore_index=True)
    else:
        df_output_error = df_output_error.append({
            'commit_id':str(commit_id)
        }, ignore_index=True)
    print('done!')

for col in df_output_commit.columns:
    if df_output_commit[col].dtype == 'object':
        df_output_commit[col] = df_output_commit[col].astype(str)

df_output_commit = df_output_commit.replace({'nan': np.nan})

df_output_commit['author_date_offset'] = pd.to_numeric(df_output_commit['author_date_offset']).astype('Int64')
df_output_commit['committer_date_offset'] = pd.to_numeric(df_output_commit['committer_date_offset']).astype('Int64')

df_output_commit.to_sql('commit', connection, if_exists='append', index=False)
df_output_commit_label.to_sql('commit_label', connection, if_exists='append', index=False)
df_output_commit_linkedissue.to_sql('commit_linkedissue', connection, if_exists='append', index=False)
df_output_commit_fixedissue.to_sql('commit_fixedissue', connection, if_exists='append', index=False)
df_output_commit_szzissue.to_sql('commit_szzissue', connection, if_exists='append', index=False)
df_output_error.to_sql('commit_error', connection, if_exists='append', index=False)

time_analysis_end = time.time()
print("Process completed in " + str(time_analysis_end - time_analysis_start) + " seconds")

# Below code is used to set None values to Null in SQLite
cursor = connection.cursor()

for table_name in ['commit', 'commit_label', 'commit_linkedissue', 'commit_fixedissue', 'commit_szzissue']:
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [column[1] for column in cursor.fetchall()]

    for column in columns:
        cursor.execute(f"UPDATE {table_name} SET {column} = NULL WHERE {column} = 'None'")

connection.commit()
connection.close()

