import pandas as pd
import numpy as np
import sqlite3 as sql
import warnings
import time
from bson import ObjectId
from mongoengine import connect, disconnect
from pymongo import MongoClient
from pycoshark.mongomodels import Project

warnings.filterwarnings('ignore', category=FutureWarning)

print("Process started!")
time_analysis_start = time.time()

# create connection to mongo db server using mongoengine i.e. with ORM
disconnect('default')
connect('smartshark_2_2', host='localhost', port=27018, alias='default')

# create connection to local sqlite db
database_name = "/Users/hdagar3/Downloads/msr2022_challenge_refactoring_summer2023.db"
connection = sql.connect(database_name)

# create connection to mongo db server using raw client
client = MongoClient("mongodb://localhost:27018/")
database = client["smartshark_2_2"]

query = 'SELECT id FROM "vcs_system"'
df = pd.read_sql_query(query, connection)
existing_vcs_system_ids = df['id'].tolist()

# counting the number of existing vcs system ids
print(len(existing_vcs_system_ids))
existing_vcs_system_ids = set(existing_vcs_system_ids)

com_query = 'SELECT DISTINCT vcs_system_id FROM "commit"'
com_df = pd.read_sql_query(com_query, connection)
com_vcs_system_ids = com_df['vcs_system_id'].tolist()
print(len(com_vcs_system_ids))  # count the total vcs system ids

vcs_system_ids_to_be_processed = set()
for com_vcs_system_id in com_vcs_system_ids:
    if str(com_vcs_system_id) not in existing_vcs_system_ids:
        vcs_system_ids_to_be_processed.add(str(com_vcs_system_id))

count_vcs_system_ids_to_be_processed = len(vcs_system_ids_to_be_processed)
print('Total distinct remaining vcs_system ids to be processed: %s' % count_vcs_system_ids_to_be_processed)

df_output_vcs_system = pd.DataFrame(columns=[
    'id',
    'url',
    'project_id',
    'repository_type',
    'last_updated',
    'repository_file'
])

df_output_project = pd.DataFrame(columns=[
    'id',
    'name'
])

count = 1
for vcs_system_id in vcs_system_ids_to_be_processed:
    if vcs_system_id is not None:
        print('Analyzing vcs_system_id %s of %s [%s]...' % (count, count_vcs_system_ids_to_be_processed, (count/count_vcs_system_ids_to_be_processed)*100.0), end='', flush=True)
        count += 1

        cursor = database["vcs_system"].find({"_id": ObjectId(vcs_system_id)})
        for doc in cursor:
            id = doc["_id"]
            url = doc["url"]
            project_id = doc["project_id"]
            repository_type = doc["repository_type"]
            last_updated = doc["last_updated"]
            repository_file = doc["repository_file"]
            project_name = Project.objects.with_id(object_id=project_id).name

            df_output_vcs_system = df_output_vcs_system.append({
                'id': str(id),
                'url': url,
                'project_id': str(project_id),
                'repository_type': repository_type,
                'last_updated': str(last_updated),
                'repository_file': str(repository_file),
            }, ignore_index=True)

            df_output_project = df_output_project.append({
                'id': str(project_id),
                'name': project_name
            }, ignore_index=True)
    else:
        print("vcs_system_id is None")

print('done!')

for col in df_output_vcs_system.columns:
    if df_output_vcs_system[col].dtype == 'object':
        df_output_vcs_system[col] = df_output_vcs_system[col].astype(str)

for col in df_output_project.columns:
    if df_output_project[col].dtype == 'object':
        df_output_project[col] = df_output_project[col].astype(str)

df_output_vcs_system = df_output_vcs_system.replace({'nan': np.nan})
df_output_project = df_output_project.replace({'nan': np.nan})

df_output_vcs_system.to_sql('vcs_system', connection, if_exists='append', index=False)
df_output_project.to_sql('project', connection, if_exists='append', index=False)

time_analysis_end = time.time()
print("Process completed in " + str(time_analysis_end - time_analysis_start) + " seconds")

# Below code is used to set None values to Null in SQLite
cursor = connection.cursor()

for table_name in ['vcs_system', 'project']:
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [column[1] for column in cursor.fetchall()]

    for column in columns:
        cursor.execute(f"UPDATE {table_name} SET {column} = NULL WHERE {column} = 'None'")

connection.commit()
connection.close()
