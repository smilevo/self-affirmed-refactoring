import pandas as pd
import numpy as np
import sqlite3 as sql
import warnings
import time
from bson import ObjectId
from mongoengine import connect, disconnect
from pycoshark.mongomodels import Refactoring
from pymongo import MongoClient


warnings.filterwarnings('ignore', category=FutureWarning)

'''
This script loads the remaining refactoring collection entries from MongoDB to SQLite DB
'''

print("Process started!")
time_analysis_start = time.time()

# create connection to mongo db server using mongoengine i.e. with ORM
disconnect('default')
connect('smartshark_2_2', host='localhost', port=27018, alias='default')

# create connection to local sqlite db
database_name = "/Users/hdagar3/Downloads/msr2022_challenge_refactoring_summer2023.sqlite"
connection = sql.connect(database_name)

query = 'SELECT id FROM "commit"'
df = pd.read_sql_query(query, connection)

existing_commit_ids = df['id'].tolist()

# if you want to count the number of commit ids
print(len(existing_commit_ids))
existing_commit_ids = set(existing_commit_ids)

commit_ids_to_be_processed = set()
commits = Refactoring.objects.distinct('commit_id')
print(type(commits), type(existing_commit_ids))
print(len(commits))

for commit_id in commits:
    if str(commit_id) not in existing_commit_ids:
        commit_ids_to_be_processed.add(str(commit_id))

count_distinct_refactoring_commits = len(commit_ids_to_be_processed)
print('Total distinct remaining refactoring commits: %s' % count_distinct_refactoring_commits)

df_output_refactoring = None
def df_init():
    global df_output_refactoring

    df_output_refactoring = pd.DataFrame(columns=[
        'id',
        'commit_id',
        'type',
        'description',
        'detection_tool',
        'parent_ce_before_id',
        'parent_ce_after_id',
        'ce_after_id',
        'ce_before_id'
    ])

df_init()

refactorings = Refactoring.objects().all()
print(type(refactorings))
count = 1
print(type(refactoring.commit_id), type(commit_ids_to_be_processed))

for refactoring in refactorings:
    if str(refactoring.commit_id) in commit_ids_to_be_processed:
        # update the `172455` number with your estimates
        print('Analyzing refactoring %s of %s [%s]...' % (count, 172455, (count / 172455) * 100.0), end='', flush=True)
        count += 1

        refactoring_ce_before = str(refactoring.ce_state['ce_before'])if 'ce_before' in refactoring.ce_state else None
        refactoring_ce_after = str(refactoring.ce_state['ce_after']) if 'ce_after' in refactoring.ce_state else None
        refactoring_parent_ce_before = str(refactoring.ce_state['parent_ce_before']) if 'parent_ce_before' in refactoring.ce_state else None
        refactoring_parent_ce_after = str(refactoring.ce_state['parent_ce_after']) if 'parent_ce_after' in refactoring.ce_state else None

        df_output_refactoring = df_output_refactoring.append({
            'id': str(refactoring.id),
            'commit_id': str(refactoring.commit_id),
            'type': refactoring.type,
            'description': refactoring.description,
            'detection_tool': refactoring.detection_tool,
            'parent_ce_before_id':refactoring_parent_ce_before,
            'parent_ce_after_id':refactoring_parent_ce_after,
            'ce_after_id':refactoring_ce_after,
            'ce_before_id':refactoring_ce_before
        }, ignore_index=True)

print('done!')

for col in df_output_refactoring.columns:
    if df_output_refactoring[col].dtype == 'object':
        df_output_refactoring[col] = df_output_refactoring[col].astype(str)

df_output_refactoring = df_output_refactoring.replace({'nan': np.nan})

df_output_refactoring.to_sql('refactoring_unique', connection, if_exists='append', index=False)

time_analysis_end = time.time()
print("Process completed in " + str(time_analysis_end - time_analysis_start) + " seconds")

# Below code is used to set None values to Null in SQLite
cursor = connection.cursor()

cursor.execute("PRAGMA table_info('refactoring_unique')")
columns = [column[1] for column in cursor.fetchall()]

for column in columns:
    cursor.execute(f"UPDATE 'refactoring_unique' SET {column} = NULL WHERE {column} = 'None'")

connection.commit()
connection.close()
