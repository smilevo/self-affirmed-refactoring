import pandas as pd
import numpy as np
import sqlite3 as sql
import warnings
import time
from bson import ObjectId
from mongoengine import connect, disconnect
from pymongo import MongoClient

warnings.filterwarnings('ignore', category=FutureWarning)

'''
This script is responsible for loading the remaining code_entity and code_entity_metric data
that is linked with refactoring_unique table in SQLite.
'''

print("Process started!")
time_analysis_start = time.time()

# create connection to mongo db server using raw client
client = MongoClient("mongodb://localhost:27018/")
database = client["smartshark_2_2"]

# create connection to local sqlite db
database_name = "/Users/hdagar3/Downloads/msr2022_challenge_refactoring_summer2023.sqlite"
connection = sql.connect(database_name)

col_names = ['ce_after_id', 'ce_before_id', 'parent_ce_after_id', 'parent_ce_before_id']
col_name_ids = set()

for col_name in col_names:
    query_ru = f'SELECT {col_name} FROM "refactoring_unique"'
    df_ru = pd.read_sql_query(query_ru, connection).dropna()

    col_name_ids.update(set(df_ru[f'{col_name}']))

print(len(col_name_ids))

query_ce = 'SELECT id FROM "code_entity"'
df_ce = pd.read_sql_query(query_ce, connection)

ce_ids_list = df_ce['id'].tolist()
ce_ids_set = set(ce_ids_list)

print(len(ce_ids_set))

ce_ids_to_be_processed = set()
for col_name_id in col_name_ids:
    if col_name_id in ce_ids_set:
        continue
    ce_ids_to_be_processed.add(col_name_id)

print(len(ce_ids_to_be_processed))

query = 'SELECT id FROM "code_entity" WHERE id IN ({})'.format(','.join(repr(str(i)) for i in ce_ids_to_be_processed))
df = pd.read_sql_query(query, connection)
print(len(df))  # making sure that we have new code entity ids


estimated_num_docs = 76689  # Update with your estimate

# Convert string ids to ObjectIds
ce_ids_to_be_processed_list = [ObjectId(ce_id) for ce_id in ce_ids_to_be_processed]

code_entity_data = []
code_entity_metric_data = []

count = 1
for ce_id in ce_ids_to_be_processed_list:
    code_entity_state = database["code_entity_state"].find_one({"_id": ce_id})
    count += 1
    print('Analyzing code_entity_state %s of %s [%s]...' % (count, estimated_num_docs, (count / estimated_num_docs) * 100.0), flush=True)

    if code_entity_state:
        code_entity_data.append({
            'id': str(code_entity_state.get("_id")) if code_entity_state.get("_id") else None,
            'ce_type': code_entity_state.get("ce_type") if code_entity_state.get("ce_type") else None,
            'commit_id': str(code_entity_state.get("commit_id")) if code_entity_state.get("commit_id") else None,
            'ce_parent_id': str(code_entity_state.get("ce_parent_id")) if code_entity_state.get("ce_parent_id") else None,
            'long_name': code_entity_state.get("long_name") if code_entity_state.get("long_name") else None
        })

        if len(code_entity_state.get("metrics", {})) > 0:
            for metric_name, metric_value in code_entity_state["metrics"].items():
                code_entity_metric_data.append({
                    'ce_id': str(code_entity_state.get("_id")) if code_entity_state.get("_id") else None,
                    'metric_name': metric_name,
                    'metric_value': str(metric_value)
                })

# Create DataFrame after collecting all the data
df_output_code_entity = pd.DataFrame(code_entity_data)
df_output_code_entity_metric = pd.DataFrame(code_entity_metric_data)

print('done!')

for col in df_output_code_entity.columns:
    if df_output_code_entity[col].dtype == 'object':
        df_output_code_entity[col] = df_output_code_entity[col].astype(str)

for col in df_output_code_entity_metric.columns:
    if df_output_code_entity_metric[col].dtype == 'object':
        df_output_code_entity_metric[col] = df_output_code_entity_metric[col].astype(str)

df_output_code_entity = df_output_code_entity.replace({'nan': np.nan})
df_output_code_entity_metric = df_output_code_entity_metric.replace({'nan': np.nan})

df_output_code_entity.to_sql('code_entity', connection, if_exists='append', index=False)
df_output_code_entity_metric.to_sql('code_entity_metric', connection, if_exists='append', index=False)

time_analysis_end = time.time()
print("Process completed in " + str(time_analysis_end - time_analysis_start) + " seconds")

# Below code is used to set None values to Null in SQLite
cursor = connection.cursor()

for table_name in ['code_entity', 'code_entity_metric']:
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [column[1] for column in cursor.fetchall()]

    for column in columns:
        cursor.execute(f"UPDATE {table_name} SET {column} = NULL WHERE {column} = 'None'")

connection.commit()
connection.close()
